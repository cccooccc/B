
</section>
    
<footer style="position: absolute;
    bottom: 2%;
    left: 44%;
    color: #ffffffa1;">
        cecopyright@ registered
    </footer>

   
    
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script> 

</body>
</html>