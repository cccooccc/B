<?php

namespace App\Http\Controllers;

//use GuzzleHttp\Psr7\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    function product(){
        $dat=DB::table('category')->orderBy('cid','desc')->paginate(2);
        return view('product',['dat'=>$dat]);
        
    }

    function product2($cat){

        $dat=DB::table('products')->where('category',$cat)->orderBy('pid','desc')->paginate(2);
        
        return view('product2',['dat'=>$dat]);
        // print_r($dat);
    
    }

    function dashboard(){
        $cat=DB::table('category')->get();
        $prod=DB::table('products')->get();
        $user=DB::table('users')->get();
        $adv=DB::table('beauty_advice')->get();

       return view('dashboard',['cat'=>$cat,'prod'=>$prod,'user'=>$user,'adv'=>$adv]);
    }

   
    function adminuser(){
        $dat2=DB::table('users')->get();
        $dat=json_decode(json_encode($dat2),true);
        $a=1;
        return view('adminuser',['dat'=>$dat,'a'=>$a]);

    }
    function delteuser(Request $req){
        $uid1=$req->uid;
        $dat2=DB::table('users')->where('user_id',$uid1)->delete();
       
        if(!$dat2){
            echo "<script> alert('User Not Removed')</script>";
        }else{
        echo "<script> alert('User Removed Succesfully')</script>";
        }
        return redirect('user');
    }

    function adminproduct(Request $req){
        $dat2=DB::table('products')->get();
        $dat=json_decode(json_encode($dat2),true);
        $a=1;
        return view('adminproduct',['dat'=>$dat,'a'=>$a]);

    }
    // function adminupd(Request $req){
    //     if(isset($_POST['remove'])){
    //         $pid=$req->pid;
    //         $dat2=DB::table('products')->where('pid',$pid)->delete();
       
    //         if(!$dat2){
    //             echo "<script> alert('Product Not Removed')</script>";
    //         }else{
    //         echo "<script> alert('Product Removed Succesfully')</script>";
    //         }
            
    //     }
        
    // }
}
