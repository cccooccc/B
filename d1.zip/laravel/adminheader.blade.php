<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMIN_COSMOTUS</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
        }

        body {
            overflow: hidden;
        }

        .con {
            position: relative;
            width: 100%;
        }

        .sidebar {
            position: fixed;
            width: 300px;
            height: 100%;
            background: linear-gradient(45deg, #47cebe, #ef4a82);
            overflow: hidden;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            z-index: 2;
        }

        .sidebar ul li {
            width: 100%;
            list-style: none;
        }

        .sidebar ul li:hover {
            background: #444;
        }

        .sidebar ul li:first-child:hover {
            background: none;
        }

        .sidebar ul li:first-child {
            line-height: 60px;
            margin-bottom: 20px;
            font-weight: 600;
            border-bottom: 1px solid #fff;
        }

        .sidebar ul li a {
            width: 100%;
            text-decoration: none;
            color: #fff;
            height: 60px;
            display: flex;
            align-items: center;
        }

        .sidebar .title {
            padding: 0 10px;
            font-size: 20px;
        }
        .main{
            position: absolute;
            width: 1214px;
            min-height: 100vh;
            left: 300px;
            background: #f5f5f5;
        }

        .navbar1 {
            position: fixed;
            height: 60px;
            width: 1219px;
            display: grid;
            justify-content: space-between;
            background: linear-gradient(45deg, #ef4a82, #47cebe);
            grid-template-columns: 10fr 0.4fr 1fr;
            grid-gap: 5px;
            align-items: center;
            color: #444;
            padding: 0 20px;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
            z-index: 1;            
           

        }
        .nav-links {
            flex: 1;
            text-align: right;
        }

        .nav-links ul li {
            list-style: none;
            display: inline-block;
            padding-bottom: 0px;
            padding-top: 16px;
            position: relative;
        }

        .nav-links ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 25px;
            font-family: "Poppins", sans-serif;

        }
          
        .bby{
            margin-top: 60px;  
            padding: 15px;
        }
    </style>
</head>

<body>
    <div class="con">
        <div class="sidebar">
            <ul>
                <li>
                    <a href="">
                        <div class="title">Cosmotus</div>
                    </a>
                </li>
                <li>
                    <a href="admin">
                        <div class="title">Dashboard</div>
                    </a>
                </li>
                <li>
                    <a href="adminproduct">
                        <div class="title">Products</div>
                    </a>
                </li>
                <li>
                    <a href="user">
                        <div class="title">Users</div>
                    </a>
                </li>
                <li>
                    <a href="admincat">
                        <div class="title">Category</div>
                    </a>
                </li>
                <li>
                    <a href="adminadvice">
                        <div class="title">Beauty Advice</div>
                    </a>
                </li>
                <li>
                    <a href="profile">
                        <div class="title">Profile</div>
                    </a>
                </li>
            </ul>
        </div>
        <div class="main">
            <div class="navbar1">
                <div class="nav-links">
                <ul>
                    <!-- <a href="login.php"> -->
                    <?php 
                    if(isset($_SESSION['admin']))
                    {
                          echo '<li><a  href="alogout.php">'.$_SESSION['admin'].'</a></li>';
                    }else{
                        echo '<li><a style="margin-left: 15px;" href="signin.php">SIGN IN</a></li>';
                    } ?>
                    <!-- <img src="pic.jpg" class="img11" alt="">
                    </a> -->
                    </ul>
                    </div>
            </div>

            <div class="bby">